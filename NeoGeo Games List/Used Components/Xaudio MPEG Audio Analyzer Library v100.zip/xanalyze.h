/*****************************************************************
|
|      MPEG Audio Analyzer
|
|      (c) 1996-1999 MpegTV, LLC
|      Author: Gilles Boccon-Gibod (gilles@mpegtv.com)
|
 ****************************************************************/

#ifndef __XANALYSE_H__
#define __XANALYZE_H__

/*----------------------------------------------------------------------
|       macros
+---------------------------------------------------------------------*/
#if defined(WIN32) || defined(_WIN32)
#define XA_EXPORT __stdcall
#else
#define XA_EXPORT
#endif                               

/*-------------------------------------------------------------------------
|       error codes
+-------------------------------------------------------------------------*/
#define XANALYZE_SUCCESS                ( 0)
#define XANALYZE_FAILURE                (-1)

#define XANALYZE_ERROR_INTERNAL         (-2)
#define XANALYSE_ERROR_OUT_OF_MEMORY    (-3)
#define XANALYZE_ERROR_NO_SUCH_FILE     (-4)
#define XANALYZE_ERROR_CANNOT_OPEN      (-5)
#define XANALYZE_ERROR_INVALID_FRAME    (-6)
#define XANALYZE_ERROR_EOF              (-7)
#define XANALYZE_ERROR_STOP_CONDITION   (-8)
#define XANALYZE_ERROR_WATCHDOG         (-9)

#define XANALYZE_INVALID_VALUE          (-1)
#define XANALYZE_ALL_FRAMES             (0)

/*-------------------------------------------------------------------------
|       constants
+-------------------------------------------------------------------------*/
#define MPEG_ID_MPEG_1                          1
#define MPEG_ID_MPEG_2                          0
#define MPEG_ID_MPEG_2_5                        2

#define MPEG_MODE_STEREO                        0
#define MPEG_MODE_JOINT_STEREO                  1
#define MPEG_MODE_DUAL_CHANNEL                  2
#define MPEG_MODE_SINGLE_CHANNEL                3

#define XANALYZE_REPORT_CHANGING_LEVEL          0x01
#define XANALYZE_REPORT_CHANGING_LAYER          0x02
#define XANALYZE_REPORT_CHANGING_BITRATE        0x04
#define XANALYZE_REPORT_CHANGING_FREQUENCY      0x08
#define XANALYZE_REPORT_CHANGING_MODE           0x10
#define XANALYZE_REPORT_CHANGING_CHANNELS       0x20

/*-------------------------------------------------------------------------
|       target specific macros
+-------------------------------------------------------------------------*/
#if defined(WIN32) || defined(_WIN32)
#define XA_EXPORT __stdcall
#define XA_IMPORT __stdcall
#else
#define XA_EXPORT
#define XA_IMPORT
#endif                                      

/*-------------------------------------------------------------------------
|       types
+-------------------------------------------------------------------------*/
typedef struct {
    int  level;
    int  layer;
    int  bitrate;
    int  frequency;
    int  mode;
    int  channels;
} AnalyzerMpegInfo;

typedef struct {
    const char   *title;
    const char   *artist;
    const char   *album;
    const char   *year;
    const char   *comment;
    unsigned char genre;
} AnalyzerTrackInfo;

typedef struct {
    AnalyzerMpegInfo  stream_type;
    AnalyzerTrackInfo track;
    unsigned long     frames;
    unsigned long     duration;
    unsigned long     flags;
} AnalyzerInfo;

/*-------------------------------------------------------------------------
|       prototypes
+-------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
                        
int XA_EXPORT xanalyzer_new(void **analyzer);
int XA_EXPORT xanalyzer_delete(void *analyzer);
int XA_EXPORT xanalyzer_process_file(void *analyzer, const char *name, 
                                     AnalyzerInfo *info, 
                                     unsigned long stop_mask,
                                     unsigned long watchdog,
                                     unsigned long max_frames);

#ifdef __cplusplus
}
#endif           

#endif /* __XANALYZE_H__ */

