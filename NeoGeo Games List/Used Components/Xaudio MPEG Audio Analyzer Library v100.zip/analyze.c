/*****************************************************************
|
|      MPEG Audio Analyzer - Sample API usage example
|
|      (c) 1996-1999 MpegTV, LLC
|      Author: Gilles Boccon-Gibod (gilles@mpegtv.com)
|
|
|      This implements a simple MP3 analyzer based on the
|      xanalyze library.
|      This is a command line tool with the following usage syntax:
|  
|      xanalyze <filename> [watchdog] [max_frames]
|
|      The program will analyze <filename> (with an optional 
|      search watchdog value and an optional max number of
|      frames to anlayze) and print out the result.
|
 ****************************************************************/

/*-------------------------------------------------------------------------
|       includes
+-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "xanalyze.h"

/*-------------------------------------------------------------------------
|       print_usage_and_exit
+-------------------------------------------------------------------------*/
static void
print_usage_and_exit(void)
{
    fprintf(stderr,
"usage: xanalyze [-w <watchdog>] [-f <max_frames>] <filename> [<filename> ...]\n"
"  <filename>:   name of file to analyze (multiple filenames can be given)\n"
"  <watchdog>:   max number of bytes to search for a sync pattern\n"
"                (default: search for ever)\n"
"  <max_frames>: maximum number of frames to analyze (default: analyze all\n"
"                frames in the file)\n");
    exit(1);
}

/*-------------------------------------------------------------------------
|       parse_command_line
+-------------------------------------------------------------------------*/
static char **
parse_command_line(char **argv, int *watchdog, int *max_frames)
{
    while (*argv) {
        if (!strcmp(*argv, "-w")) {
            if (*++argv) {
                *watchdog = strtol(*argv++, NULL, 10);
            } else {
                fprintf(stderr, "missing argument for -w option\n");
                print_usage_and_exit();
            }
        } else if (!strcmp(*argv, "-f")) {
            if (*++argv) {
                *max_frames = strtol(*argv++, NULL, 10);
            } else {
                fprintf(stderr, "missing argument for -f option\n");
                print_usage_and_exit();
            }
        } else {
            return argv;
        }
    }

    return argv;
}

/*-------------------------------------------------------------------------
|       process_file
+-------------------------------------------------------------------------*/
static void
process_file(void *analyzer, const char *filename,
             int watchdog, int max_frames)
{
    AnalyzerInfo info;
    int          status;

    /* process the file */
    status = xanalyzer_process_file(analyzer, filename, 
                                    &info, 0, 
                                    watchdog,
                                    max_frames);
    if (status) {
        fprintf(stderr, "cannot analyze file (%d)\n", status);
    }

    /* print out the results */
    printf("--------------------------------------------------------------------------\n");
    printf("INFO for %s\n", filename);
    printf("LEVEL     = %d\n",     info.stream_type.level);
    printf("LAYER     = %d\n",     info.stream_type.layer);
    printf("MODE      = %d\n",     info.stream_type.mode);
    printf("CHANNELS  = %d\n",     info.stream_type.channels);
    printf("BITRATE   = %d bps\n", info.stream_type.bitrate);
    printf("FREQUENCY = %d Hz\n",  info.stream_type.frequency);
    printf("FRAMES    = %ld\n",    info.frames);
    printf("DURATION  = %ld.%ld secs\n", 
           info.duration/1000,
           info.duration%1000);
    printf("FLAGS     = %lx\n", info.flags);     
    if (info.flags){
        printf("    Changing: ");
        if (info.flags & XANALYZE_REPORT_CHANGING_LEVEL) {
            printf("LEVEL ");
        }
        if (info.flags & XANALYZE_REPORT_CHANGING_LAYER) {
            printf("LAYER ");
        }
        if (info.flags & XANALYZE_REPORT_CHANGING_BITRATE) {
            printf("BITRATE ");
        }
        if (info.flags & XANALYZE_REPORT_CHANGING_FREQUENCY) {
            printf("FREQUENCY ");
        }
        if (info.flags & XANALYZE_REPORT_CHANGING_MODE) {
            printf("MODE ");
        }
        if (info.flags & XANALYZE_REPORT_CHANGING_CHANNELS) {
            printf("CHANNELS ");
        }
        printf("\n");
    }

    if (info.track.title) {
        printf("    TITLE   = %s\n", info.track.title);
    }
    if (info.track.artist) {
        printf("    ARTIST  = %s\n", info.track.artist);
    }
    if (info.track.album) {
        printf("    ALBUM   = %s\n", info.track.album);
    }
    if (info.track.year) {
        printf("    YEAR    = %s\n", info.track.year);
    }
    if (info.track.comment) {
        printf("    COMMENT = %s\n", info.track.comment);
    }
    printf("\n");
}

/*-------------------------------------------------------------------------
|       main
+-------------------------------------------------------------------------*/
int 
main(int argc, char **argv)
{
    void        *analyzer;
    const char  *filename;
    int          status;
    int          watchdog = 0;
    int          max_frames = 0;

    /* parse command line */
    argv = parse_command_line(argv+1, &watchdog, &max_frames);

   /* create an analyzer object */
    status = xanalyzer_new(&analyzer);
    if (status) {
        fprintf(stderr, "cannot create analyzer (%d)\n", status);
        exit(1);
    }

    while ((filename = *argv++)) {
        process_file(analyzer, filename, watchdog, max_frames);
    }

    /* delete the analyze object */
    xanalyzer_delete(analyzer);

    return 0;
}





