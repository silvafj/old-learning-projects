CoolForm 1.5 component for Delphi 3 AND 4


IMPORTANT

	You can download new versions directly at http://www.lawrenz.com/coolform/

VERY IMPORTANT!!!!!!!!!!!!
As we haven't received ANY beer yet, we would strongly advise you to get in gear and send some brew. Or else!



	
New Features:

	15.9.1998
		Coolform1.5 compatible with Delphi 4
		Included unit ExtMaskgenerator (see below)
		Fixed several bugs
		had to buy some beer
	14.9.1998
		got very thirsty
	13.9.1998
		got thirsty
	3.5.1998
		Added loading of masks at runtime.
		Added 0.9 to the version number.
		(That's what most of you've been asking for, ain't it?)
	2.5.1998
		Fixed the IDE Hangups when black is selected as transparent color
		Replaced the OpenDialog with OpenPictureDialog
		(Thanks, Garth!)
	1.3.1998
		CoolButton included
	25.2.1998
		Fixed the Access Violation Problem
		Fixed the 'Canvas does not allow drawing' Problem
		Improved the performance of the mask generator



Authors:

	Tim Lawrenz
	tim@lawrenz.com

	Max Muermann
	muermann@stud.uni-frankfurt.de


Legal Notice:

	This component is BeerWare for personal use. No responsibilities taken whatsoever.
	BeerWare means:

	1) If you want to use this component for commercial use or
	2) if you want to use this component for personal use and think that this
	   component is worth to do it,

	you have to send us 20 bottles of beer (or the money for it) (or for german developers:
	'nen Kasten Bier).


Installation:

	From the Delphi IDE, choose Components/install packages from the menu, Select
	'Add' (or something like that, only german version available here). Find Component\Cool.dpl,
	Click OK. There should be a new tab in the component palette named 'Cool'.

Usage:

	ExtMaskgenerator
	
	The unit ExtMaskGenerator.pas contains one function: ExtGenerateMask(TBitmap, TColor, String);
	You call the function with the bitmap you want to use as the mask, the color that will be transparent
	and the filename where you want to store the mask data. You can then load the mask into a TCoolForm
	with LoadMaskFromFile.
	See XDollDemo.zip for some source and a nice picture.

	CoolForm 1.5

	Just drop the CoolForm component directly on a Form.
	Load a bitmap, just like with any TImage component.
	Double-click the Mask property. (the cool-looking mask editor appears)
	You can use the image you just loaded as a source for the mask, or you can load an
	external bmp to use as mask source.
	Clicking anywhere on the image selects the transparent color. This color is
	shown in the upper right corner of the window.
	The Ok-Button (checkmark) starts the mask generation (takes some time, no optimizations yet),
	but you'll have to do it only once. 
	Compile and start your program and marvel at the wonders to behold.
	If you want your form to be draggable, set the Draggable property to true, otherwise don't.
	You can place any standard delphi component on the CoolForm, just bear in mind that components
	outside the masked area don't show. We suggest using BitButtons with Flat set to true.
	Look at the demo.


	Runtime loading: In the maskeditor, hit the 'save mask' AFTER having created a mask (you'll have
	to bring up the maskeditor twice, sorry).
	In your application, call CoolForm1.LoadMaskFromFile (FileName); It will return true if successfull,
	false if not.

	CoolButton 1.3

	The TCoolButton component is a button derived from a standard delphi SpeedButton - only cooler.
	The glyph *HAS* to contain four (4) equally sized bitmaps, of which the first describes the
	button in normal state, the second is the disabled button, the third one contains the image
	if the pressed button, the fourth one is displayed when the mouse cursor is over the button.
	We're drunk, so don't blame us.
	Oh, man, it's just a simple button! What do you want to know about it?




Future enhancements:

	If we don't receive some beer soon, there will be no more enhancements. Thats it.

Bugreports:

	Please report any bugs you should encounter with a detailed 
	description (or even some source code) to any of the abovementioned EMail-addresses

MailingList:

	Visit the Coolform Homepage for instructions on how to get on the mailinglist (we don't quite remember now).



	Have fun.



