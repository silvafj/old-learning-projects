Readme file for TEnhRombButtons component.

Author: Andrea Molino
	easytarg@mbox.vol.it

This component was created to enhance the capabilities of one free component found
on Internet (see the file ROMBBTN.TXT for original description).

The component is:
	- EROMBBTN.PAS + EROMBBTN.DCR for Dephi
	- EROMBBTN.PAS + EROMBBTN.D32 for Dephi 2.0 (rename D32 to DCR)

I have include in this package two examples for Delphi and Delphi 2.0

Enjoy!