// MfcPlayer.h : main header file for the MFCPLAYER application
//

#if !defined(AFX_MFCPLAYER_H__BC354F78_7AA3_11D2_9322_0020AFF7E192__INCLUDED_)
#define AFX_MFCPLAYER_H__BC354F78_7AA3_11D2_9322_0020AFF7E192__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "XaudioPlayer.h"

/////////////////////////////////////////////////////////////////////////////
// CMfcPlayerApp:
// See MfcPlayer.cpp for the implementation of this class
//

class CMfcPlayerApp : public CWinApp
{
public:
	CMfcPlayerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcPlayerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMfcPlayerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// SamplePlayer:
// This class is a subclass of the generic XaudioPlayer
// It overrides some methods to implement actions triggered
// by notification messages

class SamplePlayer : public XaudioPlayer
{
public:
    // member variables
    BOOL m_Scrolling;
    XA_PlayerState m_State;

    // methods
    SamplePlayer(HINSTANCE instance);
    void OnNotifyReady();
    void OnNotifyNack(XA_NackInfo *info);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCPLAYER_H__BC354F78_7AA3_11D2_9322_0020AFF7E192__INCLUDED_)
