// MfcPlayerDlg.h : header file
//

#if !defined(AFX_MFCPLAYERDLG_H__BC354F7A_7AA3_11D2_9322_0020AFF7E192__INCLUDED_)
#define AFX_MFCPLAYERDLG_H__BC354F7A_7AA3_11D2_9322_0020AFF7E192__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CMfcPlayerDlg dialog

class CMfcPlayerDlg : public CDialog
{
// Construction
public:
    SamplePlayer *m_Player1;
    SamplePlayer *m_Player2;
	CMfcPlayerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMfcPlayerDlg)
	enum { IDD = IDD_MFCPLAYER_DIALOG };
	CSliderCtrl	m_VolumeSlider2;
	CSliderCtrl	m_VolumeSlider1;
	CSliderCtrl	m_PitchSlider2;
	CSliderCtrl	m_PitchSlider1;
	CButton	m_File2Button;
	CButton	m_File1Button;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcPlayerDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMfcPlayerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnUseDirectsoundRadio();
	afx_msg void OnUseWaveRadio();
	afx_msg void OnFile1Button();
	afx_msg void OnFile2Button();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCPLAYERDLG_H__BC354F7A_7AA3_11D2_9322_0020AFF7E192__INCLUDED_)
