##############################################################
#
# Xaudio DirectSound Output Module
# Sample MFC Program
#
##############################################################

This programs shows in a simple way how to have 2 player
objects decode streams at the same time, and have them mix
by a DirectSound output. It also shows how to change the 
pitch of the output sound of each stream.

To run this, you will need to copy the Xaudio DirectSound
Output Module (xa_dsound_output.dll) to this directory, as
well as the main xaudio.dll (unless it is already somewhere
in your path).
