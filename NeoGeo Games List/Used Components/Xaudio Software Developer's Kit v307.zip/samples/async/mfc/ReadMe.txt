##############################################################
#
# Xaudio Sample Player for MFC
#
##############################################################

This programs shows in a simple way how create a player using
the Xaudio ASYNC API.

To run this, you will need to copy the Xaudio runtime
library xaudio.dll (unless it is already somewhere in your 
path).
