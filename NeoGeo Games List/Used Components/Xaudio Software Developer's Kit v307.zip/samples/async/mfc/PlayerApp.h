// PlayerApp.h : main header file for the MFCPLAYER application
//

#if !defined(AFX_PLAYERAPP_H__FCF45C44_7793_11D2_9317_0020AFF7E192__INCLUDED_)
#define AFX_PLAYERAPP_H__FCF45C44_7793_11D2_9317_0020AFF7E192__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "XaudioPlayer.h"

/////////////////////////////////////////////////////////////////////////////
// CPlayerApp:
// See PlayerApp.cpp for the implementation of this class
//

class CPlayerApp : public CWinApp
{
public:
	CPlayerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlayerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPlayerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// SamplePlayer:
// This class is a subclass of the generic XaudioPlayer
// It overrides some methods to implement actions triggered
// by notification messages

class SamplePlayer : public XaudioPlayer
{
public:
    // member variables
    BOOL m_Scrolling;
    XA_PlayerState m_State;

    // methods
    SamplePlayer(HINSTANCE instance);
    void OnNotifyReady();
    void OnNotifyNack(XA_NackInfo *info);
    void OnNotifyPlayerState(XA_PlayerState state);
    void OnNotifyInputPosition(unsigned long offset, unsigned long range);
    void OnNotifyInputName(const char *name);
    void OnNotifyInputState(XA_InputState state);
    void OnNotifyInputDuration(unsigned long duration);
    void OnNotifyInputTimecode(XA_TimecodeInfo *info);
    void OnNotifyInputStreamInfo(XA_StreamInfo *info);
    void OnNotifyInputModuleInfo(XA_ModuleInfo *info);
    void OnNotifyOutputState(XA_OutputState state);
    void OnNotifyOutputModuleInfo(XA_ModuleInfo *info);
    void OnNotifyOutputMasterLevel(unsigned char level);
    void OnNotifyOutputPcmLevel(unsigned char level);
    void OnNotifyOutputBalance(unsigned char balance);
    void OnNotifyCodecEqualizer(XA_EqualizerInfo *equalizer);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYERAPP_H__FCF45C44_7793_11D2_9317_0020AFF7E192__INCLUDED_)
