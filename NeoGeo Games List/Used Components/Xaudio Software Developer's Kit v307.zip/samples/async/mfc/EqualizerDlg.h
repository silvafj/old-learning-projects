#if !defined(AFX_EQUALIZERDLG_H__30315641_79E9_11D2_9322_0020AFF7E192__INCLUDED_)
#define AFX_EQUALIZERDLG_H__30315641_79E9_11D2_9322_0020AFF7E192__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// EqualizerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEqualizerDlg dialog

class CEqualizerDlg : public CDialog
{
// Construction
public:
	CEqualizerDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEqualizerDlg)
	enum { IDD = IDD_EQUALIZER_DIALOG };
	CButton	m_EnableEQCheckBox;
	CSliderCtrl	m_Slider8;
	CSliderCtrl	m_Slider7;
	CSliderCtrl	m_Slider6;
	CSliderCtrl	m_Slider5;
	CSliderCtrl	m_Slider4;
	CSliderCtrl	m_Slider3;
	CSliderCtrl	m_Slider2;
	CSliderCtrl	m_Slider1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEqualizerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEqualizerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnEnableEqCheckbox();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void UpdateValues();
};

/////////////////////////////////////////////////////////////////////////////
// Globals
extern CEqualizerDlg *EqualizerDialog;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EQUALIZERDLG_H__30315641_79E9_11D2_9322_0020AFF7E192__INCLUDED_)
