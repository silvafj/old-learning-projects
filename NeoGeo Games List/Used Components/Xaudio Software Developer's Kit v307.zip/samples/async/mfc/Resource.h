//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mfcplayer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PLAYER_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDD_ENTER_URL_DIALOG            129
#define IDI_XAUDIO_ICON                 129
#define IDC_CURSOR1                     130
#define IDI_WEB_ICON                    131
#define IDD_INFO_DIALOG                 132
#define IDD_VOLUME_DIALOG               133
#define IDD_EQUALIZER_DIALOG            134
#define IDC_VOLUME_BUTTON               1000
#define IDC_STOP_BUTTON                 1001
#define IDC_PLAY_BUTTON                 1002
#define IDC_ABOUT_BUTTON                1003
#define IDC_INFO_BUTTON                 1004
#define IDC_SLIDER                      1005
#define IDC_EQUALIZER_BUTTON            1006
#define IDC_DURATION_LABEL              1007
#define IDC_URL_EDIT                    1007
#define IDC_TIMECODE_LABEL              1008
#define IDC_NAME_LABEL                  1009
#define IDC_OPEN_FILE_BUTTON            1010
#define IDC_OPEN_URL_BUTTON             1011
#define IDC_TYPE_LABEL                  1012
#define IDC_STATE_LABEL                 1013
#define IDC_AUTOPLAY_CHECKBOX           1014
#define IDC_INPUT_LIST                  1015
#define IDC_OUTPUT_LIST                 1016
#define IDC_LIBRARY_VERSION_LABEL       1017
#define IDC_MASTER_SLIDER               1018
#define IDC_PCM_SLIDER                  1019
#define IDC_BALANCE_SLIDER              1020
#define IDC_ENABLE_EQ_CHECKBOX          1021
#define IDC_SLIDER1                     1022
#define IDC_SLIDER2                     1023
#define IDC_SLIDER3                     1024
#define IDC_SLIDER4                     1025
#define IDC_SLIDER5                     1026
#define IDC_SLIDER6                     1027
#define IDC_SLIDER7                     1028
#define IDC_SLIDER8                     1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
