// mfcplayerDlg.h : header file
//

#if !defined(AFX_PLAYERDLG_H__FCF45C46_7793_11D2_9317_0020AFF7E192__INCLUDED_)
#define AFX_PLAYERDLG_H__FCF45C46_7793_11D2_9317_0020AFF7E192__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// Includes

#include "XaudioPlayer.h"
#include "PlayerApp.h"

/////////////////////////////////////////////////////////////////////////////
// CMfcplayerDlg dialog

class CPlayerDlg : public CDialog
{
// Construction
public:
    SamplePlayer *m_Player;
	CPlayerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPlayerDlg)
	enum { IDD = IDD_PLAYER_DIALOG };
	CButton	m_AutoPlayCheckBox;
	CButton	m_InfoButton;
	CButton	m_VolumeButton;
	CButton	m_StopButton;
	CButton	m_PlayButton;
	CStatic	m_DurationLabel;
	CStatic	m_TypeLabel;
	CStatic	m_TimecodeLabel;
	CSliderCtrl	m_Slider;
	CStatic	m_NameLabel;
	CStatic	m_StateLabel;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlayerDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPlayerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPlayButton();
	afx_msg void OnOpenFileButton();
	afx_msg void OnStopButton();
	afx_msg void OnOpenUrlButton();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnAboutButton();
	afx_msg void OnInfoButton();
	afx_msg void OnVolumeButton();
	afx_msg void OnEqualizerButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYERDLG_H__FCF45C46_7793_11D2_9317_0020AFF7E192__INCLUDED_)
